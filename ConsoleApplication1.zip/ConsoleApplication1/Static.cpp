extern "C" __declspec(dllimport) char* RemoveSub(char*, char*, int);

#include <cstdio>
#include <windows.h>
#include <iostream>
int main() {
	char str[256], res[256];
	int number;
	std::cout << "Input string: ";
	std::cin.get(str, 256);
	if (str[0] == '\0') {
		std::cout << "Empty string";
		system("pause");
		return 1;
	}
	std::cout << "Size: ";
	std::cin >> number;
	if (number < 1) {
		std::cout << "Number error(must be > 0)";
		system("pause");
		return 2;
	}
	RemoveSub(str, res, number);
	std::cout << "Result: ";
	std::cout << res;
	system("pause");

	return 0;
}