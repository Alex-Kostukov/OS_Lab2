extern "C" __declspec(dllimport) char* fun(char*, char*, int);

#include <cstdio>
#include <windows.h>
#include <iostream>
int main()
{
	char str[256], res[256];
	int number;
	printf("Input string: ");
	std::cin.get(str, 256);
	if (str[0] == '\0')
		return 1;
	std::cout << "Size: ";
	std::cin >> number;
	if (number < 1)
		return 2;
	fun(str, res, number);
	std::cout << "Result: ";
	std::cout << res;
	system("pause");

	return 0;
}
